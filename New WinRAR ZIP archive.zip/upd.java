import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class upd extends JFrame implements ActionListener
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5,l6,l7,l8;
JButton b1,b2,b3,b4,b5;
JComboBox jb,jb1,jb2;
JScrollPane jsp;
JTextField j1,j2,j3,j4;
PreparedStatement pst;
Statement st;
ResultSet rx;
upd()
{
con=getContentPane();
con.setLayout(null);
Color c=new Color(173,255,47);
con.setBackground(c);
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
cn=DriverManager.getConnection("jdbc:odbc:gp");

}
catch(Exception ee)
{
JOptionPane.showMessageDialog(this,"Database Error"+ee);
}


l1=new JLabel("UPDATE ITEMS");
l1.setBounds(600,15,600,50);
l1.setFont(new Font("CALIBRI",Font.ITALIC,50));
l1.setForeground(new Color(0,0,128));
con.add(l1);
l2=new JLabel("NAME");
l2.setBounds(100,100,700,60);
l2.setFont(new Font("CALIBRI",Font.ITALIC,40));
l2.setForeground(new Color(0,0,128));
con.add(l2); 
j1=new JTextField();
j1.setBounds(350,115,400,30);
con.add(j1);
l3=new JLabel("QUANTITY");
l3.setBounds(100,200,700,60);
l3.setFont(new Font("CALIBRI",Font.ITALIC,40));
l3.setForeground(new Color(0,0,128));
con.add(l3);
j2=new JTextField();
j2.setBounds(350,215,400,30);
con.add(j2);
l4=new JLabel("RATE");
l4.setBounds(100,300,700,60);
l4.setFont(new Font("CALIBRI",Font.ITALIC,40));
l4.setForeground(new Color(0,0,128));
con.add(l4);
j3=new JTextField();
j3.setBounds(350,315,400,30);
con.add(j3);


b1=new JButton("UPDATE");
b1.setBounds(350,500,120,50);
b1.setFont(new Font("",Font.BOLD,15));
Color c3=new Color(240,255,255);
b1.setBackground(c3);
con.add(b1);
b1.addActionListener(this);


b2=new JButton("BACK");
b2.setBounds(540,500,120,50);
b2.setFont(new Font("",Font.BOLD,15));
Color c8=new Color(240,255,255);
b2.setBackground(c8);
con.add(b2);
b2.addActionListener(this);


ImageIcon icon4=new ImageIcon("mg.JPG");
l6= new JLabel(icon4);
l6.setBounds(0,0,2000,1000);
con.add(l6);

show();
setSize(1700,1000);
}
public void actionPerformed(ActionEvent ee)
{
	if(ee.getSource()==b2)
	{
		new stock();
	}
	if(ee.getSource()==b1)
{
try
{
pst=cn.prepareStatement("update stock set quantity='"+j2.getText()+"',rate='"+j3.getText()+"' where name='"+j1.getText()+"'");
pst.executeUpdate();
pst.close();
j1.setText("");
j2.setText("");
j3.setText("");
}catch(Exception e)
{
JOptionPane.showMessageDialog(this,"Database Error"+e);
}
}
}
public static void main(String sr[])
{
new upd();
}
}