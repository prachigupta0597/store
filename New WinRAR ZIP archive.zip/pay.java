import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class pay extends JFrame implements ActionListener
{
static String k;
Connection cn,cn1;
Container con;
int a,b,c;
JLabel l1,l2,l3,l4,l5,l6,l7;
JButton b1,b2,b3;
JComboBox jb,jb1,jb2;
PreparedStatement pst;
JScrollPane jsp;
Vector v;
String x,y;
JList jl1,jl2,jl3;
JTextField j1,j2,j3;
Statement st,st1;
ResultSet rx,rx1;
pay()
{
con=getContentPane();
con.setLayout(null);
Color c=new Color(152,251,152);
con.setBackground(c);

l1=new JLabel("MODE OF PAYMENT");
l1.setBounds(500,15,900,50);
l1.setFont(new Font("STENCIL",Font.ITALIC,50));
l1.setForeground(new Color(255,255,0));
con.add(l1);
l2=new JLabel("SELECT YOUR PAYMENT METHOD");
l2.setBounds(100,200,900,50);
l2.setFont(new Font("STENCIL",Font.ITALIC,50));
l2.setForeground(new Color(255,255,0));
con.add(l2);

l3=new JLabel("TOTAL");
l3.setBounds(100,400,900,50);
l3.setFont(new Font("STENCIL",Font.ITALIC,50));
l3.setForeground(new Color(255,255,0));
con.add(l3);
j1= new JTextField(String.valueOf(sale.c));
j1= new JTextField(String.valueOf(purchase.d));
j1.setBounds(350,410,580,40);
con.add(j1);

b1=new JButton("PAY");
b1.setBounds(500,600,120,50);
b1.setFont(new Font("",Font.BOLD,15));
con.add(b1);
b1.addActionListener(this);

b2=new JButton("PURCHASE");
b2.setBounds(650,600,120,50);
b2.setFont(new Font("",Font.BOLD,15));
con.add(b2);
b2.addActionListener(this);

b3=new JButton("HOME");
b3.setBounds(795,600,120,50);
b3.setFont(new Font("",Font.BOLD,15));
con.add(b3);
b3.addActionListener(this);


v=new Vector();
v.add("SELECT MODE");
v.add("CASH");
v.add("CARD");
v.add("CHEQUE");
jb=new JComboBox(v);
jb.setBounds(980,200,150,50);
con.add(jb);

ImageIcon icon4=new ImageIcon("mon.JPEG");
l6= new JLabel(icon4);
l6.setBounds(0,0,1950,1000);
con.add(l6);


show();
setSize(2000,1700);
}
public void actionPerformed(ActionEvent ee)
{
if(ee.getSource()==b3)
{
new log();
}
	if(ee.getSource()==b2)
	{
		new purchase();
	}
		
if(ee.getSource()==b1)
{
	k=String.valueOf(jb.getSelectedItem());
	if(k=="CHEQUE")
	{
	new cheq();
	}
	if(k=="CARD")
	{
new card();
	}	
	if(k=="CASH")
	{
		new rec();
	}
}
}
public static void main(String sr[])
{
new pay();
}
}