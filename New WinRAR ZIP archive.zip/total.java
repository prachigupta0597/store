import java.util.*;
class total
{
public static void main(String S[])
{
Scanner sc=new Scanner(System.in);
System.out.print("enter value");
int a=sc.nextInt();
System.out.print("enter value");
int b=sc.nextInt();
int c=a+b;
System.out.print("sum is"+c);
}
}
