import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class add extends JFrame implements ActionListener
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5,l6,l7,l8;
JButton b1,b2,b3,b4,b5;
JComboBox jb,jb1,jb2;
JScrollPane jsp;
JTextField j1,j2,j3,j4;
PreparedStatement pst;
Statement st;
ResultSet rx;
add()
{
con=getContentPane();
con.setLayout(null);

try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
cn=DriverManager.getConnection("jdbc:odbc:gp");

}
catch(Exception ee)
{
JOptionPane.showMessageDialog(this,"Database Error"+ee);
}


l1=new JLabel("SELECT YOUR QUANTITY");
l1.setBounds(500,15,600,50);
l1.setFont(new Font("CALIBRI",Font.ITALIC,50));
con.add(l1);
l2=new JLabel("NAME");
l2.setBounds(100,100,700,60);
l2.setFont(new Font("CALIBRI",Font.ITALIC,40));
con.add(l2); 
j1=new JTextField();
j1.setBounds(350,115,400,30);
con.add(j1);
l3=new JLabel("QUANTITY");
l3.setBounds(100,200,700,60);
l3.setFont(new Font("CALIBRI",Font.ITALIC,40));
con.add(l3);
j2=new JTextField();
j2.setBounds(350,215,400,30);
con.add(j2);
l4=new JLabel("RATE");
l4.setBounds(100,300,700,60);
l4.setFont(new Font("CALIBRI",Font.ITALIC,40));
con.add(l4);
j3=new JTextField();
j3.setBounds(350,315,400,30);
con.add(j3);


b1=new JButton("NEXT");
b1.setBounds(300,530,120,50);
b1.setFont(new Font("",Font.BOLD,15));
con.add(b1);
b1.addActionListener(this);

b2=new JButton("BACK");
b2.setBounds(450,530,120,50);
b2.setFont(new Font("",Font.BOLD,15));
con.add(b2);
b2.addActionListener(this);
ImageIcon icon4=new ImageIcon("bgg.JPG");
l6= new JLabel(icon4);
l6.setBounds(0,0,2000,1000);
con.add(l6);
show();
setSize(2500,1700);
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==b1)
{
try
{
pst=cn.prepareStatement("insert into stock values(?,?,?)");
pst.setString(1,j1.getText());
pst.setString(2,j2.getText());
pst.setString(3,j3.getText());
pst.executeUpdate();
pst.close();
new log();
}catch(Exception ee)
{
JOptionPane.showMessageDialog(this,"Database Error"+ee);
}
}
if(e.getSource()==b2)
{
new stock();
}
}
public static void main(String sr[])
{
new add();
}
}