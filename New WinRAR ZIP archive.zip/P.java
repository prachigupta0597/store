import java.util.*;
class P
{
public static void main (String S[])
{
scanner sc=new scanner (System.in);
System.out.print("enter the value");
int a=sc.nextint();
System.out.print("enter the value");
int b=sc.nextint();
if(a==5)
}
if(b==9)
{
System.out.print("H");
}
else
{
System.out.print("P");
}
}
else
{
System.out.print("k");
}
}
}