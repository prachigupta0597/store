import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class login extends JFrame implements ActionListener
{
Connection cn;
Container con;
JLabel l1,l2,l3;
JTextField j1,j2;
JButton b1;
login()
{
con=getContentPane();
con.setLayout(null);
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
cn=DriverManager.getConnection("jdbc:odbc:pg");
JOptionPane.showMessageDialog(this,"Database Connected");
}catch(Exception e)
{
JOptionPane.showMessageDialog(this,"Databse Error"+e);
}	
l1= new JLabel("Enter Details");
l1.setBounds(300,15,900,30);
l1.setFont(new Font("",Font.ITALIC,30));
con.add(l1);
j1= new JTextField();
j1.setBounds(300,160,300,30);
con.add(j1);
l2= new JLabel("User Name");
l2.setBounds(100,150,350,40);
l2.setFont(new Font("",Font.ITALIC,30));
con.add(l2);
l3= new JLabel("Password");
l3.setBounds(100,250,350,40);
l3.setFont(new Font("",Font.ITALIC,30));
con.add(l3);
j2= new JTextField();
j2.setBounds(300,260,300,30);
con.add(j2);
b1= new JButton("Login");
b1.setBounds(400,350,90,30);
con.add(b1);
b1.addActionListener(this);
show();
setSize(900,500);
}
public void actionPerformed(ActionEvent s)
{
	
}
public static void main(String sr[])
{
new login();
}
}	