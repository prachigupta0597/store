import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class unp  extends JFrame
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4;
JButton b1,b2,b3,b4,b5;
JTextField j1,j2,j3;
JPasswordField jp;
PreparedStatement pst;
Statement st;
ResultSet rx;
unp()
{
con=getContentPane();
con.setLayout(null);
ImageIcon icon1=new ImageIcon("wel.JPG");
l1= new JLabel(icon1);
l1.setBounds(500,15,500,200);
con.add(l1);
l2=new JLabel("USER NAME OR EMAIL ADDRESS");
l2.setBounds(500,300,600,50);
l2.setFont(new Font("",Font.ITALIC,30));
con.add(l2);
j1= new JTextField();
j1.setBounds(500,360,580,40);
con.add(j1);
l3=new JLabel("PASSWORD");
l3.setBounds(500,420,600,50);
l3.setFont(new Font("",Font.ITALIC,30));
con.add(l3);
jp= new JPasswordField();
jp.setBounds(500,475,400,40);
con.add(jp);
ImageIcon icon=new ImageIcon("wl.PNG");
l4= new JLabel(icon);
l4.setBounds(0,0,2000,1500);
con.add(l4);
b1=new JButton("GO");
b1.setBounds(600,600,200,40);
b1.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,30));
con.add(b1);
show();
setSize(1500,1500);
}
public static void main(String sr[])
{
new unp();
}
}
