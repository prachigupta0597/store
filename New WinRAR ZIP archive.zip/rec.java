import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class rec extends JFrame implements ActionListener
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15;
JButton b1,b2,b3,b4,b5;
JComboBox jb,jb1,jb2;
JScrollPane jsp;
JTextField j1,j2,j3,j4,j5;
JPasswordField jp;
PreparedStatement pst;
Statement st;
ResultSet rx;
rec()
{
con=getContentPane();
con.setLayout(null);
l1=new JLabel("RECEIPT");
l1.setBounds(500,15,600,50);
l1.setFont(new Font("CALIBRI",Font.ITALIC,50));
con.add(l1);
l2=new JLabel("NAME");
l2.setBounds(100,100,700,60);
l2.setFont(new Font("CALIBRI",Font.ITALIC,40));
con.add(l2); 
l7=new JLabel(sale.s2);
l7.setBounds(400,115,400,30);
con.add(l7);
l12=new JLabel(purchase.s2);
l12.setBounds(400,115,400,30);
con.add(l12);
l3=new JLabel("QUANTITY");
l3.setBounds(100,200,700,60);
l3.setFont(new Font("CALIBRI",Font.ITALIC,40));
con.add(l3);
l8=new JLabel(sale.s3);
l8.setBounds(400,215,400,30);
con.add(l8);
l12=new JLabel(purchase.s3);
l12.setBounds(400,215,400,30);
con.add(l12);
l4=new JLabel("RATE");
l4.setBounds(100,300,700,60);
l4.setFont(new Font("CALIBRI",Font.ITALIC,40));
con.add(l4);
l9=new JLabel(sale.s4);
l9.setBounds(400,315,400,30);
con.add(l9);
l14=new JLabel(purchase.s4);
l14.setBounds(400,315,400,30);
con.add(l14);
l5=new JLabel("VALUE");	
l5.setBounds(100,400,700,60);
l5.setFont(new Font("CALIBRI",Font.ITALIC,40));
con.add(l5);
l10=new JLabel(sale.s1);
l10.setBounds(400,415,400,30);
con.add(l10);
l15=new JLabel(purchase.s1);
l15.setBounds(400,415,400,30);
con.add(l15);
l6=new JLabel("PAYMENT MODE");	
l6.setBounds(100,500,700,60);
l6.setFont(new Font("CALIBRI",Font.ITALIC,40));
con.add(l6);
l11=new JLabel(pay.k);
l11.setBounds(400,515,400,30);
con.add(l11);
b1=new JButton("PRINT");
b1.setBounds(400,600,120,50);
b1.setFont(new Font("",Font.BOLD,15));
con.add(b1);
b1.addActionListener(this);
ImageIcon icon4=new ImageIcon("lp.PNG");
l6= new JLabel(icon4);
l6.setBounds(0,0,1900,1000);
con.add(l6);
show();
setSize(2000,2000);
}

public void actionPerformed(ActionEvent e)
{
if(e.getSource()==b1)
{
	new close();
}
}

public static void main(String sr[])
{
new rec();
}
}