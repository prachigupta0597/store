import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*; 
class sale extends JFrame implements ActionListener
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5,l6,l7,l8;
JButton b1,b2,b3,b4,b5;
JComboBox jb,jb1,jb2,jb3;
JScrollPane jsp;
static String q;

static String s1,s2,s3,s4,s5;
int a,b;
static int c;
JTextField j1,j2,j3,j4;
PreparedStatement pst;
Statement st;
ResultSet rx;
sale()
{
con=getContentPane();
con.setLayout(null);
Color c=new Color(255,250,250);
con.setBackground(c);
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
cn=DriverManager.getConnection("jdbc:odbc:gp");

}catch(Exception e)
{
JOptionPane.showMessageDialog(this,"Database ERROR"+e);
}
l1=new JLabel("SELECT YOUR QUANTITY");
l1.setBounds(500,15,1600,90);
l1.setFont(new Font("BRADLEY HAND ITC",Font.ITALIC,70));
l1.setForeground(Color.BLACK);
con.add(l1);
l2=new JLabel("ITEM NAME");
l2.setBounds(100,100,700,60);
l2.setFont(new Font("BRADLEY HAND ITC",Font.ITALIC,40));
con.add(l2); 
j1=new JTextField(s2);
j1.setBounds(350,115,400,30);
con.add(j1);
l3=new JLabel("RATE");
l3.setBounds(100,200,700,60);
l3.setFont(new Font("BRADLEY HAND ITC",Font.ITALIC,40));
con.add(l3);
j2=new JTextField(s3);
j2.setBounds(350,215,400,30);
con.add(j2);
l4=new JLabel("QUANTITY");
l4.setBounds(100,300,700,60);
l4.setFont(new Font("BRADLEY HAND ITC",Font.ITALIC,40));
con.add(l4);
j3=new JTextField(s4);
j3.setBounds(350,315,400,30);
con.add(j3);
l5=new JLabel("VALUE");	
l5.setBounds(100,400,700,60);
l5.setFont(new Font("BRADLEY HAND ITC",Font.ITALIC,40));
con.add(l5);
j4=new JTextField();
j4.setBounds(350,415,400,30);
con.add(j4);
b1=new JButton("NEXT");
b1.setBounds(200,530,120,50);
b1.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,15));
con.add(b1);
b1.addActionListener(this);

b2=new JButton("TOTAL");
b2.setBounds(330,530,120,50);
b2.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,15));
con.add(b2);
b2.addActionListener(this);


b3=new JButton("BACK");
b3.setBounds(460,530,120,50);
b3.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,15));
con.add(b3);
b3.addActionListener(this);

ImageIcon icon4=new ImageIcon("gb.JPG");
l6= new JLabel(icon4);
l6.setBounds(0,0,1800,1000);
con.add(l6);

show();
setSize(2000,1700);
}
public void actionPerformed(ActionEvent ee)
{
	
		if(ee.getSource()==b2)
{
	a=Integer.parseInt(j2.getText());
	b=Integer.parseInt(j3.getText());
	c=a*b;
	j4.setText(String.valueOf(c));
	s1=j4.getText();
	
	
}
if(ee.getSource()==b1)
{
s2=j1.getText();
s3=j3.getText();
s4=j2.getText();
	
	/*q=String.valueOf(jb3.getSelectedItem());
	try{
		st=cn.createStatement();
		rx=st.executeQuery("select * from stock where name='"+q+"'");
		while(rx.next());
		{
			j2.setText(rx.getString(1));
			j3.setText(rx.getString(3));
		}
		//j1.setText(n);
	}
	catch(Exception e)
	{
		JOptionPane.showMessageDialog(this,"Database ERROR"+e);
	}
}*/

		new pay();
}
if(ee.getSource()==b3)
{
	new stock();
}
}
public static void main(String sr[])
{
new sale();
}
}