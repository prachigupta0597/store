import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class slt extends JFrame 
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5,l6;
JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
JTextField j1,j2,j3,j4,j5,j6;
JCheckBox jcb1, jcb2;
PreparedStatement pst;
Statement st;
ResultSet rx;
JTable jt;
slt()
{
con=getContentPane();
con.setLayout(null);
Color c=new Color(240,255,255);
con.setBackground(c);
l1=new JLabel("PURCHASE ITEMS");
l1.setBounds(700,15,900,40);
l1.setFont(new Font("STENCIL",Font.ITALIC,40));
con.add(l1);
l2=new JLabel("ITEM NAME");
l2.setBounds(100,200,900,40);
l2.setFont(new Font("STENCIL",Font.ITALIC,40));
con.add(l2);
j1=new JTextField();
j1.setBounds(400,200,300,40);
con.add(j1);
l3=new JLabel("QUANTITY");
l3.setBounds(100,300,900,40);
l3.setFont(new Font("STENCIL",Font.ITALIC,40));
con.add(l3);
j2=new JTextField();
j2.setBounds(400,300,300,40);
con.add(j2);
l4=new JLabel("RATE");
l4.setBounds(100,400,900,40);
l4.setFont(new Font("STENCIL",Font.ITALIC,40));
con.add(l4);
j3=new JTextField();
j3.setBounds(400,400,300,40);
con.add(j3);
l5=new JLabel("CO.NAME");
l5.setBounds(100,500,900,40);
l5.setFont(new Font("STENCIL",Font.ITALIC,40));
con.add(l5);
j4=new JTextField();
j4.setBounds(400,500,300,40);
con.add(j4);
b1=new JButton("NEXT");
b1.setBounds(250,700,100,50);
con.add(b1);
show();
setSize(900,900);
}
public static void main(String sr[])
{
new slt();
}
}