import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class logg extends JFrame 
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5;
JButton b1,b2,b3,b4,b5;
PreparedStatement pst;
Statement st;
ResultSet rx;
JTable jt;
logg()
{
con=getContentPane();
con.setLayout(null);
Color c=new Color(48, 200, 199);
con.setBackground(c);
l1=new JLabel("GOEL GENRAL STORE");
l1.setBounds(600,15,900,30);
l1.setFont(new Font("",Font.ITALIC,40));
l1.setForeground(Color.RED);
con.add(l1);

show();
setSize(900,900);
}
public static void main(String sr[])
{
new logg();
}
}