import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class shopp extends JFrame 
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5;
JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
JTextField j1,j2,j3,j4,j5,j6;
JCheckBox jcb1, jcb2;
PreparedStatement pst;
Statement st;
ResultSet rx;
JTable jt;
shopp()
{
con=getContentPane();
con.setLayout(null);
Color c=new Color(48, 144, 199);
con.setBackground(c);
l1=new JLabel("*****WELCOME TO OUR SHOP*****");
l1.setBounds(500,15,900,30);
l1.setFont(new Font("",Font.ITALIC,40));
l1.setForeground(Color.BLUE);
con.add(l1);
l2=new JLabel("USER");
l2.setBounds(100,130,900,30);
l2.setFont(new Font("",Font.ITALIC,30));
l2.setForeground(Color.BLUE);
con.add(l2);
j1= new JTextField();
j1.setBounds(100,210,300,30);
con.add(j1);
l3=new JLabel("PASSWORD");
l3.setBounds(100,300,300,30);
l3.setFont(new Font("",Font.ITALIC,30));
l3.setForeground(Color.BLUE);
con.add(l3);
j2= new JTextField();
j2.setBounds(100,380,300,30);
con.add(j2);
l4=new JLabel("ADMIN");
l4.setBounds(600,130,900,30);
l4.setFont(new Font("",Font.ITALIC,30));
l4.setForeground(Color.BLUE);
con.add(l4);
j3=new JTextField();
j3.setBounds(600,210,300,30);
con.add(j3);
l5=new JLabel("PASSWORD");
l5.setBounds(600,300,300,30);
l5.setFont(new Font("",Font.ITALIC,30));
l5.setForeground(Color.BLUE);
con.add(l5);
j4=new JTextField();
j4.setBounds(600,380,300,30);
con.add(j4);
b1=new JButton("GO");
b1.setBounds(410,380,120,30);
con.add(b1);
b2=new JButton("GO");
b2.setBounds(910,380,120,30);
con.add(b2);
b3=new JButton("SWITCH");
b3.setBounds(400,500,150,40);
con.add(b3);
show();
setSize(900,900);
}
public static void main(String sr[])
{
new shopp();
}
}