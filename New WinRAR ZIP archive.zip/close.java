import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class close extends JFrame implements ActionListener
{
Container con;
JLabel l1,l2,l3,l4,l5,l6;
JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
PreparedStatement pst;
Statement st;
ResultSet rx;

close()
{
con=getContentPane();
Color c=new Color(178,34,34);
con.setBackground(c);


ImageIcon icon7=new ImageIcon("smile.JPG");
l2= new JLabel(icon7);
l2.setBounds(1353,360,800,900);
con.add(l2);



ImageIcon icon5=new ImageIcon("close.JPG");
l1= new JLabel(icon5);
l1.setBounds(550,50,500,900);
con.add(l1);

show();
setSize(2000,1500);
}
public void actionPerformed(ActionEvent ee)
{

}
public static void main(String sr[])
{
new close();
}
}