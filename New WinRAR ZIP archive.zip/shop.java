import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class shop extends JFrame 
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5,l6;
JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
JTextField j1,j2,j3,j4,j5,j6;
JPasswordField jp,jp1;
JCheckBox jcb1, jcb2;
PreparedStatement pst;
Statement st;
ResultSet rx;
JTable jt;
shop()
{
con=getContentPane();
con.setLayout(null);
Color c=new Color(255,182,193);
con.setBackground(c);
l1=new JLabel("*****WELCOME TO OUR SHOP*****");
l1.setBounds(500,15,900,30);
l1.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,40));
l1.setForeground(Color.RED);
con.add(l1);
ImageIcon icon=new ImageIcon("store.JPG");
l6= new JLabel(icon);
l6.setBounds(1300,25,500,500);
con.add(l6);
l2=new JLabel("USER");
l2.setBounds(100,130,900,30);
l2.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,40));
l2.setForeground(Color.RED);
con.add(l2);
j1= new JTextField();
j1.setBounds(100,210,300,30);
con.add(j1);
l3=new JLabel("PASSWORD");
l3.setBounds(100,300,300,30);
l3.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,40));
l3.setForeground(Color.RED);
con.add(l3);
jp= new JPasswordField();
jp.setBounds(100,380,300,30);
con.add(jp);
l4=new JLabel("ADMIN");
l4.setBounds(600,130,900,30);
l4.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,40));
l4.setForeground(Color.RED);
con.add(l4);
j3=new JTextField();
j3.setBounds(600,210,300,30);
con.add(j3);
l5=new JLabel("PASSWORD");
l5.setBounds(600,300,300,30);
l5.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,40));
l5.setForeground(Color.RED);
con.add(l5);
jp1= new JPasswordField();
jp1.setBounds(600,380,300,30);
con.add(jp1);
b1=new JButton("GO");
b1.setBounds(410,380,120,30);
b1.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,20));
Color c3=new Color(221,160,221);
b1.setBackground(c3);
con.add(b1);
b2=new JButton("GO");
b2.setBounds(910,380,120,30);
b2.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,20));
Color c2=new Color(221,160,221);
b2.setBackground(c2);
con.add(b2);
b3=new JButton("SWITCH");
b3.setBounds(400,500,170,50);
b3.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,30));
Color c1=new Color(221,160,221);
b3.setBackground(c1);
con.add(b3);
show();
setSize(900,900);
}
public static void main(String sr[])
{
new shop();
}
}