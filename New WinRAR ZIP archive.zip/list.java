import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class list extends JFrame implements ActionListener
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5,l6,l7;
JButton b1,b2,b3,b4,b5;
Object ob[][]=new Object[100][100];
String ap[]={"Name","Quantity","Rate","Co Name"};
JTable jt;
static String s1,s2,s3,s4,s5,s6;
PreparedStatement pst;
Statement st;
ResultSet rx;
list()
{
con=getContentPane();
con.setLayout(null);
Color c=new Color(220,20,60);
con.setBackground(c);
try
{
	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	cn=DriverManager.getConnection("jdbc:odbc:gp");
	
}
catch(Exception e)
{
JOptionPane.showMessageDialog(this,"DatabseERORR"+e);
}
l1=new JLabel("ITEM LIST");
l1.setBounds(800,15,900,50);
l1.setFont(new Font("GIGI",Font.ITALIC,70));
con.add(l1);
ImageIcon icon1=new ImageIcon("up.PNG");
b1= new JButton(icon1);
b1.setBounds(800,700,100,100);
con.add(b1);
b1.addActionListener(this);
ImageIcon icon2=new ImageIcon("py.PNG");
b2= new JButton(icon2);
b2.setBounds(1000,700,100,100);
con.add(b2);
b2.addActionListener(this);

int i=0;
try
{
st=cn.createStatement();
rx=st.executeQuery("select * from purchase");
while(rx.next())
{
ob[i][0]=rx.getString(1);
ob[i][1]=rx.getString(2);
ob[i][2]=rx.getString(3);
	i++;
}
}
catch(Exception e)
{
JOptionPane.showMessageDialog(this,"Database ERROR"+e);
}
jt=new JTable(ob,ap);
JScrollPane jp=new JScrollPane(jt);
jp.setBounds(660,120,600,500);
jt.setBackground(Color.BLACK);
jt.setForeground(Color.YELLOW);
con.add(jp); 
show();
setSize(1500,1000);
}

	public void actionPerformed(ActionEvent ee)
{
	
if(ee.getSource()==b1)
{
	new purchase();
}
if(ee.getSource()==b2)
{
	
	new pay();
}
}
public static void main(String sr[])
{
new list();
}
}