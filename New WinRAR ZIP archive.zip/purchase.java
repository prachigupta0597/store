import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class purchase extends JFrame implements ActionListener
{
String tt;
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5,l6;
JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
JTextField j1,j2,j3,j4,j5,j6;
JCheckBox jcb1, jcb2;
JComboBox cb;

String ap[]={"Item Name","Quantity","Rate","Co Name"};
static String s1,s2,s3,s4,s5,s6;
int a,b;
static int d;
PreparedStatement pst;
Statement st;
ResultSet rx;
JTable jt;
Vector v;

purchase()
{
con=getContentPane();
con.setLayout(null);
Color c=new Color(240,255,255);
con.setBackground(c);
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
cn=DriverManager.getConnection("jdbc:odbc:gp");

}
catch(Exception e)
{
JOptionPane.showMessageDialog(this,"Database Error"+e);
}

l1=new JLabel("PURCHASE ITEMS");
l1.setBounds(700,15,900,40);
l1.setFont(new Font("STENCIL",Font.ITALIC,40));
con.add(l1);

l5=new JLabel("SELECT ITEMS");
l5.setBounds(100,80,900,40);
l5.setFont(new Font("STENCIL",Font.ITALIC,40));
con.add(l5);


l2=new JLabel("ITEM NAME");
l2.setBounds(100,200,900,40);
l2.setFont(new Font("STENCIL",Font.ITALIC,40));
con.add(l2);
j5=new JTextField();
j5.setBounds(400,200,300,40);
con.add(j5);
/*cb=new JComboBox();
cb.setBounds(400,200,100,30);
con.add(cb);*/
l3=new JLabel("QUANTITY");
l3.setBounds(100,300,900,40);
l3.setFont(new Font("STENCIL",Font.ITALIC,40));
con.add(l3);
j2=new JTextField();
j2.setBounds(400,300,300,40);
con.add(j2);
String p;
v=new Vector();
try 
{
st=cn.createStatement();
rx=st.executeQuery("select * from stock");
while(rx.next())
{	
p=(rx.getString(1));
v.add(p);
}
cb=new JComboBox(v);
cb.setBounds(400,70,100,30);
con.add(cb);
}
catch(Exception e)
{
JOptionPane.showMessageDialog(this,"Database ERORR"+e);
}



l4=new JLabel("RATE");
l4.setBounds(100,400,900,40);
l4.setFont(new Font("STENCIL",Font.ITALIC,40));
con.add(l4);
j3=new JTextField();
j3.setBounds(400,400,300,40);
con.add(j3);
l5=new JLabel("CO NAME");
l5.setBounds(100,500,900,40);
l5.setFont(new Font("STENCIL",Font.ITALIC,40));
con.add(l5);
j4=new JTextField();
j4.setBounds(400,500,300,40);
con.add(j4);

l6=new JLabel("TOTAL");
l6.setBounds(100,600,900,40);
l6.setFont(new Font("STENCIL",Font.ITALIC,40));
con.add(l6);
j6=new JTextField();
j6.setBounds(400,600,300,40);
con.add(j6);

b1=new JButton("NEXT");
b1.setBounds(290,700,100,50);
con.add(b1);

b2=new JButton("SELECT");
b2.setBounds(410,700,100,50);
con.add(b2);

b3=new JButton("TOTAL");
b3.setBounds(530,700,100,50);
con.add(b3);

b1.addActionListener(this);
b2.addActionListener(this);
b3.addActionListener(this);
show();	
setSize(900,900);
}
public void actionPerformed(ActionEvent ee)
{
	if(ee.getSource()==b1)
	{

try{
pst=cn.prepareStatement("insert into purchase values(?,?,?,?)");
pst.setString(1,j5.getText());
pst.setString(2,j2.getText());	
pst.setString(3,j3.getText());
pst.setString(4,j4.getText());
pst.executeUpdate();
pst.close();
new list();
}
catch(Exception e)
{

JOptionPane.showMessageDialog(this,"Database ERROR"+e);

}
}

if(ee.getSource()==b2)
{
tt=(String)cb.getSelectedItem();

try{
		st=cn.createStatement();
		rx=st.executeQuery("select * from stock where Name='"+tt+"'");
		while(rx.next())
		{
		j5.setText(rx.getString(1));
		     j3.setText(rx.getString(3));
			
			 
}
		
			
	}
	catch(Exception e)
	{
		JOptionPane.showMessageDialog(this,"Database ERROR"+e);
	}
}
if(ee.getSource()==b3)
{
	a=Integer.parseInt(j2.getText());
	b=Integer.parseInt(j3.getText());
	d=a*b;
	j6.setText(String.valueOf(d));
	s1=j6.getText();
	
	
s2=j5.getText();
s3=j2.getText();
s4=j3.getText();
s5=j4.getText();
}
}	
public static void main(String sr[])
{
new purchase();
}
}
