import java.awt.*;
import javax.swing.*;
class gp extends JFrame
 {
 Container con;
gp()
{
con=getContentPane();
con.setLayout(null);
con.setBackground(Color.white);
show();
setSize(1500,1500);
setResizable(true);
setTitle("Notepad");
setLocation(100,100);

JMenu m1,m2,m3,m4,m5;
JMenuBar jm;
JMenuItem t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17,t18,t19,t20,t21,t22;
 jm=new JMenuBar();
 m1=new JMenu("File");
 t1=new JMenuItem("New Ctrl+N ");
 t2=new JMenuItem("Open Ctrl+O");
 t3=new JMenuItem("Save Ctrl+S");
 t4=new JMenuItem("Save As");
 t5=new JMenuItem("Page Setup");
 t6=new JMenuItem("Print Ctrl+P");
 
 m2=new JMenu("Edit");
 t7=new JMenuItem("Undo ctrl+z");
 t8=new JMenuItem("Cut ctrl+x");
 t9=new JMenuItem("Copy ctrl+c");
 t10=new JMenuItem("Paste ctrl+v");
 t11=new JMenuItem("Delete del");
 t12=new JMenuItem("Find ctrl+f");
 t13=new JMenuItem("Fint Next f3");
 t14=new JMenuItem("Replace ctrl+h");
 t15=new JMenuItem("Go To ctrl+g");
 t16=new JMenuItem("Select All ctrl+a");
 t17=new JMenuItem("Time/date f5");
 
 m3=new JMenu("Format");
 t18=new JMenuItem("Word Wrap");
 t19=new JMenuItem("Font");
 
 m4=new JMenu("View");
 t20=new JMenuItem("Status Bar");
 m5=new JMenu("Help");
 t21=new JMenuItem("View Help");
 t22=new JMenuItem("About Notepad");
 
 JTextArea jt;
 jt=new JTextArea();
 jt.setBounds(0,0,1500,1500);
 con.add(jt);
 
 jm.add(m1);
 jm.add(m2);
 m1.add(t1);
 m1.add(t2);
 m1.add(t3);
m1.add(t4);
m1.add(t5);
m1.add(t6);
m2.add(t7);
m2.add(t8);
m2.add(t9);
m2.add(t10);
m2.add(t11);
m2.add(t12);
m2.add(t13);
m2.add(t14);
m2.add(t15);
m2.add(t16);
m2.add(t17); 
jm.add(m3); 
m3.add(t18);
m3.add(t19);
jm.add(m4);
m4.add(t20);
jm.add(m5);
m5.add(t21);
m5.add(t22);
 setJMenuBar(jm);

 

}
public static void main(String s[])
{
	new gp();
}
 }

