import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class del extends JFrame implements ActionListener
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5,l6,l7,l8;
JButton b1,b2,b3,b4,b5;
JComboBox jb,jb1,jb2;
JScrollPane jsp;
JTextField j1,j2,j3,j4;
PreparedStatement pst;
Statement st;
ResultSet rx;
del()
{
con=getContentPane();
con.setLayout(null);
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
cn=DriverManager.getConnection("jdbc:odbc:gp");

}
catch(Exception ee)
{
JOptionPane.showMessageDialog(this,"Database Error"+ee);
}


l1=new JLabel("DELETE ITEM");
l1.setBounds(500,15,600,50);
l1.setFont(new Font("Ravie",Font.ITALIC,50));
Color c5=new Color(173,255,47);
l1.setBackground(c5);

con.add(l1);

l2=new JLabel("ITEM NAME");
l2.setBounds(70,200,400,40);
l2.setFont(new Font("Ravie",Font.ITALIC,30));
Color c4=new Color(173,255,47);
l2.setBackground(c4);
con.add(l2);


b1=new JButton("DELETE");
b1.setBounds(300,500,120,50);
b1.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,20));
Color c3=new Color(240,255,255);
b1.setBackground(c3);
con.add(b1);

b2=new JButton("BACK");
b2.setBounds(470,500,120,50);
b2.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,20));
Color c7=new Color(240,255,255);
b2.setBackground(c4);
con.add(b2);

b1.addActionListener(this);
b2.addActionListener(this);


j1=new JTextField();
j1.setBounds(340,205,400,30);
con.add(j1);

ImageIcon icon4=new ImageIcon("delt.JPG");
l6= new JLabel(icon4);
l6.setBounds(0,0,2000,1000);
con.add(l6);

show();
setSize(1500,1000);
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==b2)
{
	new stock();
}
if(e.getSource()==b1)
{
try
{
pst=cn.prepareStatement("delete from stock where name='"+j1.getText()+"'");
pst.executeUpdate();
pst.close();
}catch(Exception ee)
{
JOptionPane.showMessageDialog(this,"Database Error"+e);
}
}
}
public static void main(String sr[])
{
new del();
}
}