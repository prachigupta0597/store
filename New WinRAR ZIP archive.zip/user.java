import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class user extends JFrame implements ActionListener
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5,l6;
JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
JTextField j1,j2,j3,j4,j5,j6;
JPasswordField jp,jp1;
static String s1,s2;
String username=null,password=null;
PreparedStatement pst;
Statement st;
ResultSet rx;

user()
{
con=getContentPane();
con.setLayout(null);
Color c=new Color(255,182,193);
con.setBackground(c);
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
cn=DriverManager.getConnection("jdbc:odbc:gp");

}
catch(Exception e)
{
JOptionPane.showMessageDialog(this,"Database ERROR"+e);
}
l1=new JLabel("*****WELCOME TO OUR SHOP*****");
l1.setBounds(500,15,900,30);
l1.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,40));
l1.setForeground(Color.YELLOW);
con.add(l1);

l2=new JLabel("USER");
l2.setBounds(100,130,900,30);
l2.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,40));
l2.setForeground(Color.RED);
con.add(l2);
j1= new JTextField();
j1.setBounds(100,210,300,30);
con.add(j1);
l3=new JLabel("PASSWORD");
l3.setBounds(100,300,300,30);
l3.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,40));
l3.setForeground(Color.RED);
con.add(l3);
jp= new JPasswordField();
jp.setBounds(100,380,300,30);
con.add(jp);
b1=new JButton("GO");
b1.setBounds(410,380,120,30);
b1.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,20));
Color c3=new Color(221,160,221);
b1.setBackground(c3);
con.add(b1);
b1.addActionListener(this);

b2=new JButton("EXIT");
b2.setBounds(550,380,120,30);
b2.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,20));
Color c4=new Color(221,160,221);
b2.setBackground(c4);
con.add(b2);
b2.addActionListener(this);
ImageIcon icon=new ImageIcon("sky.JPG");
l6= new JLabel(icon);
l6.setBounds(0,0,1920,1000);
con.add(l6);

show();
setSize(1490,900);
}
public void actionPerformed(ActionEvent ee)
{
String u=j1.getText();
String p=jp.getText();
if(u!=""||p!="")
{
if(ee.getSource()==b1)
{
}
s1=j1.getText();
try{	
Statement st=cn.createStatement();
ResultSet rx=st.executeQuery("select * from login");
while(rx.next())
{
username=rx.getString(1);
password=rx.getString(2);
 int k=0;
if(username.compareTo(u)==0 && password.compareTo(p)==0)
if (k==0)
{
hide();	
new log();
}
else
{
JOptionPane.showMessageDialog(this,"Details Matched");
}
}
}
catch(Exception e)
{
JOptionPane.showMessageDialog(this,"Database ERROR"+e);
}
}	
if(ee.getSource()==b2)
{
new admin();	
}
}

public static void main(String sr[])
{
new user();
}
}