import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class cheq  extends JFrame implements ActionListener
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16,l17;
JButton b1,b2,b3,b4,b5;
JTextField j1,j2,j3,j4,j5,j6,j7,j8,j9,j10,j11,j12,j13,j14,j15;
PreparedStatement pst;
Statement st;
ResultSet rx;
cheq()
{
con=getContentPane();
con.setLayout(null);
Color c=new Color(240,248,255);
con.setBackground(c);
l1=new JLabel("Cheque Details");
l1.setBounds(500,15,600,50);
l1.setFont(new Font("CALIBRI",Font.ITALIC,40));
con.add(l1);
l5=new JLabel("BANK NAME");
l5.setBounds(20,100,600,50);
l5.setFont(new Font("CALIBRI",Font.ITALIC,25));
con.add(l5);
j11= new JTextField();
j11.setBounds(200,107,500,35);
con.add(j11);
l2=new JLabel("PAY");
l2.setBounds(50,200,600,30);
l2.setFont(new Font("CALIBRI",Font.ITALIC,20));
con.add(l2);
j1= new JTextField();
j1.setBounds(150,205,500,25);
con.add(j1);
l17=new JLabel("RUPEES");
l17.setBounds(50,280,600,30);
l17.setFont(new Font("CALIBRI",Font.ITALIC,20));
con.add(l17);
l4=new JLabel("A/C");
l4.setBounds(50,360,600,30);
l4.setFont(new Font("CALIBRI",Font.ITALIC,20));
con.add(l4);
j12= new JTextField();
j12.setBounds(150,365,430,25);
con.add(j12);
ImageIcon icon=new ImageIcon("rp.PNG");
l16= new JLabel(icon);
l16.setBounds(270,57,800,480);
con.add(l16);
j14=new JTextField();
j14.setBounds(683,283,90,28);
con.add(j14);


j2= new JTextField();
j2.setBounds(150,285,500,25);
con.add(j2);
j3= new JTextField();
j3.setBounds(900,100,30,25);
con.add(j3);
j4= new JTextField();
j4.setBounds(930,100,30,25);
con.add(j4);
j5= new JTextField();
j5.setBounds(960,100,30,25);
con.add(j5);
j6= new JTextField();
j6.setBounds(990,100,30,25);
con.add(j6);
j7= new JTextField();
j7.setBounds(1020,100,30,25);
con.add(j7);
j8= new JTextField();
j8.setBounds(1050,100,30,25);
con.add(j8);
j9= new JTextField();
j9.setBounds(1080,100,30,25);
con.add(j9);
j10=new JTextField();
j10.setBounds(1110,100,30,25);
con.add(j10);
l6=new JLabel("D");
l6.setBounds(910,120,600,30);
l6.setFont(new Font("CALIBRI",Font.BOLD,15));
con.add(l6);
l7=new JLabel("D");
l7.setBounds(940,120,600,30);
l7.setFont(new Font("CALIBRI",Font.BOLD,15));
con.add(l7);
l8=new JLabel("M");
l8.setBounds(970,120,600,30);
l8.setFont(new Font("CALIBRI",Font.BOLD,15));
con.add(l8);
l9=new JLabel("M");
l9.setBounds(1000,120,600,30);
l9.setFont(new Font("CALIBRI",Font.BOLD,15));
con.add(l9);
l10=new JLabel("Y");
l10.setBounds(1030,120,600,30);
l10.setFont(new Font("CALIBRI",Font.BOLD,15));
con.add(l10);
l11=new JLabel("Y");
l11.setBounds(1060,120,600,30);
l11.setFont(new Font("CALIBRI",Font.BOLD,15));
con.add(l11);
l12=new JLabel("Y");
l12.setBounds(1090,120,600,30);
l12.setFont(new Font("CALIBRI",Font.BOLD,15));
con.add(l12);
l13=new JLabel("Y");
l13.setBounds(1120,120,600,30);
l13.setFont(new Font("CALIBRI",Font.BOLD,15));
con.add(l13);
l14=new JLabel("Or Bearer");
l14.setBounds(650,200,600,30);
l14.setFont(new Font("CALIBRI",Font.BOLD,20));
con.add(l14);
l15=new JLabel("Please sign above");
l15.setBounds(1120,370,600,30);
l15.setFont(new Font("CALIBRI",Font.BOLD,15));
con.add(l15);
l16=new JLabel(" ''Pay at par at all our Branches in India'' ");
l16.setBounds(50,430,600,30);
l16.setFont(new Font("CALIBRI",Font.BOLD,15));
con.add(l16);
j13=new JTextField();
j13.setBounds(1120,310,130,60);
con.add(j13);
b1=new JButton("DONE");
b1.setBounds(500,500,100,50);
b1.setFont(new Font("",Font.BOLD,15));
con.add(b1);
b1.addActionListener(this);
show();
setSize(1300,600);
}
public void actionPerformed(ActionEvent ee)
{
	if(ee.getSource()==b1)
	{
		new rec();
	}
}
public static void main(String sr[])
{
new cheq();
}

}
