import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class log extends JFrame implements ActionListener
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5,l6,l7;
JButton b1,b2,b3,b4,b5;
PreparedStatement pst;
Statement st;
ResultSet rx;
log()
{
con=getContentPane();
con.setLayout(null);
l1=new JLabel("INDIA MART");
l1.setBounds(720,30,1500,90);
l1.setFont(new Font("Latin",Font.BOLD,80));
l1.setForeground(new Color(255,255,0));
con.add(l1);
ImageIcon icon5=new ImageIcon("jl.GIF");
b1= new JButton(icon5);
b1.setBounds(1600,30,250,250);
con.add(b1);
b1.addActionListener(this);

b2=new JButton("NEW USER");
b2.setBounds(500,800,100,50);
b2.setFont(new Font("",Font.BOLD,12));
con.add(b2);
b2.addActionListener(this);

ImageIcon icon1=new ImageIcon("new.JPG");
l3= new JLabel(icon1);
l3.setBounds(602,572,50,500);
con.add(l3);
b3=new JButton("STOCK");
b3.setBounds(700,800,100,50);
b3.setFont(new Font("",Font.BOLD,12));
con.add(b3);
b3.addActionListener(this);

ImageIcon icon2=new ImageIcon("stock.JPG");
l4= new JLabel(icon2);
l4.setBounds(802,572,50,500);
con.add(l4);
b4=new JButton("PURCHASE");
b4.setBounds(900,800,100,50);
b4.setFont(new Font("",Font.BOLD,12));
con.add(b4);
b4.addActionListener(this);

ImageIcon icon3=new ImageIcon("pur.PNG");
l5= new JLabel(icon3);
l5.setBounds(1005,572,50,500);
con.add(l5);

b5=new JButton("SALE");
b5.setBounds(1100,800,100,50);
b5.setFont(new Font("",Font.BOLD,12));
con.add(b5);
b5.addActionListener(this);

ImageIcon icon7=new ImageIcon("sale.PNG");
l7= new JLabel(icon7);
l7.setBounds(1200,572,50,500);
con.add(l7);

ImageIcon icon4=new ImageIcon("lgg.JPG");
l6= new JLabel(icon4);
l6.setBounds(0,0,1900,1000);
con.add(l6);
show();
setSize(2000,1500);
}
public void actionPerformed(ActionEvent ee)
{
if(ee.getSource()==b1)
{
new admin();
}
if(ee.getSource()==b2)
{
new newuser();
}
if(ee.getSource()==b3)
{
new stock();
}
if(ee.getSource()==b4)
{
new purchase();
}
if(ee.getSource()==b5)
{
new sale();
}
}	
public static void main(String sr[])
{
new log();
}
}