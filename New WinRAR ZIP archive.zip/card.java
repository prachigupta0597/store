import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class card extends JFrame implements ActionListener
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;
JButton b1,b2,b3,b4,b5;
JComboBox jb,jb1,jb2;
JScrollPane jsp;
Vector v,v1;
JList jl1,jl2,jl3,j4;
JTextField j1,j2,j3;
JPasswordField jp;
PreparedStatement pst;
Statement st;
ResultSet rx;
card()
{
con=getContentPane();
con.setLayout(null);
ImageIcon icon=new ImageIcon("card.JPG");
l3= new JLabel(icon);
l3.setBounds(800,15,750,550);
con.add(l3);
l1=new JLabel("ENTER YOUR CARD DETAILS");
l1.setBounds(100,15,900,30);
l1.setFont(new Font("",Font.BOLD,30));
l1.setForeground(Color.WHITE);
con.add(l1);
l2=new JLabel("Card no.");
l2.setBounds(100,200,900,30);
l2.setFont(new Font("",Font.BOLD,30));
l2.setForeground(Color.WHITE);
con.add(l2);
j1= new JTextField();
j1.setBounds(100,240,400,30);
con.add(j1);
v=new Vector();
v.add("mm");
v.add("1");
v.add("2");
v.add("3");
v.add("4");
v.add("5");
v.add("6");
v.add("7");
v.add("8");
v.add("9");
v.add("10");
v.add("11");
v.add("12");
jb=new JComboBox(v);
jsp=new JScrollPane(jb);
jsp.setBounds(370,300,60,30);
con.add(jsp);
v1=new Vector();
v1.add("yy");
v1.add("2019");
v1.add("2020");
v1.add("2021");
v1.add("2022");
v1.add("2023");
v1.add("2024");
v1.add("2025");
v1.add("2026");
v1.add("2027");
v1.add("2028");
v1.add("2029");
v1.add("2030");
jb1=new JComboBox(v1);
jsp=new JScrollPane(jb1);
jsp.setBounds(430,300,60,30);
con.add(jsp);
l4=new JLabel("VALID");
l4.setBounds(335,290,900,30);
l4.setFont(new Font("",Font.BOLD,10));
l4.setForeground(Color.WHITE);
con.add(l4);
l5=new JLabel("THRU");
l5.setBounds(335,300,900,30);
l5.setFont(new Font("",Font.BOLD,10));
l5.setForeground(Color.WHITE);
con.add(l5);
l6=new JLabel("NAME ON CARD");
l6.setBounds(100,390,900,30);
l6.setFont(new Font("",Font.BOLD,30));
l6.setForeground(Color.WHITE);
con.add(l6);	
j2= new JTextField();
j2.setBounds(100,430,400,30);
con.add(j2);
l8= new JLabel("cvv");
l8.setBounds(345,480,900,30);
l8.setFont(new Font("",Font.BOLD,30));
l8.setForeground(Color.WHITE);
con.add(l8);
jp= new JPasswordField();
jp.setBounds(400,480,100,30);
con.add(jp);
b1=new JButton("DONE");
b1.setBounds(500,800,200,40);
b1.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,30));
con.add(b1);
b1.addActionListener(this);

ImageIcon icon1=new ImageIcon("cd.JPG");
l7= new JLabel(icon1);
l7.setBounds(0,0,1950,1000);
con.add(l7);
show();
setSize(700,700);
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==b1)
{
	new rec();
}
}
public static void main(String sr[])
{
new card();
}
}