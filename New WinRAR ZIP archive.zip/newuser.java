import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class newuser extends JFrame implements ActionListener
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5;
JButton b1,b2,b3,b4,b5;
JTextField j1,j2,j3;
JPasswordField jp,jp1;
String name=null;
PreparedStatement pst;
Statement st;
ResultSet rx;
newuser()
{
con=getContentPane();
con.setLayout(null);

try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
cn=DriverManager.getConnection("jdbc:odbc:gp");

}catch(Exception e)
{
JOptionPane.showMessageDialog(this,"Database ERROR"+e);
}
ImageIcon icon1=new ImageIcon("wel.JPG");
l1= new JLabel(icon1);
l1.setBounds(500,15,500,200);
con.add(l1);
l2=new JLabel("USER NAME OR EMAIL ADDRESS");
l2.setBounds(500,300,600,50);
l2.setFont(new Font("",Font.ITALIC,30));
con.add(l2);
j1= new JTextField();
j1.setBounds(500,360,580,40);
con.add(j1);
l3=new JLabel("PASSWORD");
l3.setBounds(500,420,600,50);
l3.setFont(new Font("",Font.ITALIC,30));
con.add(l3);
jp= new JPasswordField();
jp.setBounds(500,475,400,40);
con.add(jp);

l4=new JLabel(" CONFORM PASSWORD");
l4.setBounds(500,535,600,50);
l4.setFont(new Font("",Font.ITALIC,30));
con.add(l4);
jp1= new JPasswordField();
jp1.setBounds(500,590,400,40);
con.add(jp1);

l5=new JLabel("ENTER VALID MOBILE NUMBER");
l5.setBounds(500,650,600,50);
l5.setFont(new Font("",Font.ITALIC,30));
con.add(l5);
j2= new JTextField();
j2.setBounds(500,710,400,40);
con.add(j2);

b1=new JButton("GO");
b1.setBounds(500,800,200,40);
b1.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,30));
con.add(b1);
b1.addActionListener(this);

b2=new JButton("LOGIN");
b2.setBounds(730,800,200,40);
b2.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,30));
con.add(b2);
b2.addActionListener(this);

ImageIcon icon=new ImageIcon("wl.PNG");
l4= new JLabel(icon);
l4.setBounds(0,0,2000,1500);
con.add(l4);
show();
setSize(1500,1500);
}
public void actionPerformed(ActionEvent ee)
{
String nammail=j1.getText();
String c=j2.getText();
String p=jp.getText();
String conp=jp1.getText();
if(nammail!=""||c!=""||p!=""||conp!="")
{
if(ee.getSource()==b1)
{
try
{
pst=cn.prepareStatement("insert into login values(?,?,?,?)");
pst.setString(1,j1.getText());
pst.setString(2,jp.getText());
pst.setString(3,jp1.getText());
pst.setString(4,j2.getText());
pst.executeUpdate();
pst.close();
}
catch(Exception e)	
{
JOptionPane.showMessageDialog(this,"insert data"+e);
}
} 	
{
new user();
}
if(ee.getSource()==b2)
{
new log();
}
}
}
public static void main(String sr[])
{
new newuser();
}
}
