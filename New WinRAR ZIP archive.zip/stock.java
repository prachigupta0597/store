import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class stock extends JFrame implements ActionListener
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5,l6;
JButton b1,b2,b3,b4,b5;
JTable j1;
Object ob[][]=new Object[100][100];
String ap[]={"Name","Quantity","Rate/qty"};
PreparedStatement pst;
Statement st;
ResultSet rx;
stock()
{
con=getContentPane();
con.setLayout(null);
try
{
	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	cn=DriverManager.getConnection("jdbc:odbc:gp");
	
}
catch(Exception e)
{
JOptionPane.showMessageDialog(this,"DatabseERORR"+e);
}
	

l1=new JLabel("STOCK DETAILS");
l1.setBounds(700,15,900,50);
l1.setFont(new Font("JOKERMAN",Font.ITALIC,60));
l1.setForeground(Color.BLACK);
con.add(l1);


ImageIcon icon5=new ImageIcon("arr.JPG");
b5= new JButton(icon5);
b5.setBounds(1700,15,100,100);
con.add(b5);
b5.addActionListener(this);

b4=new JButton("SHOW");
b4.setBounds(1300,702,100,50);
b4.setFont(new Font("",Font.BOLD,15));
con.add(b4);
b4.addActionListener(this);
	
b1=new JButton("ADD");
b1.setBounds(700,700,100,50);
b1.setFont(new Font("",Font.BOLD,15));
con.add(b1);
b1.addActionListener(this);

b2=new JButton("DELETE");
b2.setBounds(900,702,100,50);
b2.setFont(new Font("",Font.BOLD,15));
con.add(b2);
b2.addActionListener(this);
b3=new JButton("UPDATE");
b3.setBounds(1100,702,100,50);
b3.setFont(new Font("",Font.BOLD,15));
con.add(b3);
b3.addActionListener(this);
ImageIcon icon=new ImageIcon("skk.JPG");
l6= new JLabel(icon);
l6.setBounds(0,0,1920,1000);
con.add(l6);
show();
setSize(2000,1000);
}
int i=0;
public void actionPerformed(ActionEvent ee)
{
if(ee.getSource()==b1)
{
	new add();
}
 if(ee.getSource()==b5)
 {
	 new log();
 }
	if(ee.getSource()==b2)
	{
		new del();
	}
	if(ee.getSource()==b3)
	{
		new upd();
	}
	if(ee.getSource()==b4)
{
	
try
{


st=cn.createStatement();
rx=st.executeQuery("select * from stock");
while(rx.next())
{
ob[i][0]=rx.getString(1);
ob[i][1]=rx.getString(2);
ob[i][2]=rx.getString(3);
	i++;
}
}
catch(Exception e)
{
JOptionPane.showMessageDialog(this,"Database ERROR"+e);
}
j1=new JTable(ob,ap);
JScrollPane jp=new JScrollPane(j1);
jp.setBounds(660,120,600,500);
j1.setBackground(Color.BLACK);
j1.setForeground(Color.YELLOW);
con.add(jp);
}
}	
public static void main(String sr[])
{	
new stock();
}
}
