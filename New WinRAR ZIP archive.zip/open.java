import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class open extends JFrame implements ActionListener
{
Container con;
JLabel l1,l2,l3,l4,l5,l6;
JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
PreparedStatement pst;
Statement st;
ResultSet rx;

open()
{
con=getContentPane();
con.setLayout(null);
Color c=new Color(255,20,147);
con.setBackground(c);
ImageIcon icon5=new ImageIcon("com.GIF");
l1= new JLabel(icon5);
l1.setBounds(490,50,900,400);
con.add(l1);



ImageIcon icon=new ImageIcon("click.JPG");
b2= new JButton(icon);
b2.setBounds(700,500,500,200);
con.add(b2);
b2.addActionListener(this);

ImageIcon icon4=new ImageIcon("ltr.JPG");
l6= new JLabel(icon4);
l6.setBounds(0,0,2000,1000);
con.add(l6);

show();
setSize(1700,1700);
}
public void actionPerformed(ActionEvent ee)
{
if(ee.getSource()==b2)
{
new admin();
}
}
public static void main(String sr[])
{
new open();
}
}