import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class admin extends JFrame implements ActionListener
{
Connection cn;
Container con;
JLabel l1,l2,l3,l4,l5,l6;
JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
JTextField j1,j2,j3,j4,j5,j6;
JPasswordField jp,jp1;
JCheckBox jcb1, jcb2;
PreparedStatement pst;
Statement st;
ResultSet rx;
JTable jt;
admin()
{
con=getContentPane();
con.setLayout(null);
Color c=new Color(255,182,193);
con.setBackground(c);
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
cn=DriverManager.getConnection("jdbc:odbc:gp");

}
catch(Exception e)
{
JOptionPane.showMessageDialog(this,"Database ERROR"+e);
}
l1=new JLabel("*****WELCOME TO OUR SHOP*****");
l1.setBounds(500,15,900,30);
l1.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,40));
l1.setForeground(Color.WHITE);
con.add(l1);

l2=new JLabel("ADMIN");
l2.setBounds(100,130,900,30);
l2.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,40));
l2.setForeground(Color.WHITE);
con.add(l2);
j1= new JTextField();
j1.setBounds(100,210,300,30);
con.add(j1);
l3=new JLabel("PASSWORD");
l3.setBounds(100,300,300,30);
l3.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,40));
l3.setForeground(Color.WHITE);
con.add(l3);
jp= new JPasswordField();
jp.setBounds(100,380,300,30);
con.add(jp);
b1=new JButton("GO");
b1.setBounds(410,380,120,30);
b1.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,20));
Color c3=new Color(221,160,221);
b1.setBackground(c3);
con.add(b1);
b1.addActionListener(this);


b3=new JButton("SWITCH");
b3.setBounds(400,500,170,50);
b3.setFont(new Font("BRADLEY HAND ITC",Font.BOLD,30));
Color c1=new Color(221,160,221);
b3.setBackground(c1);
con.add(b3);
b3.addActionListener(this);

ImageIcon icon=new ImageIcon("sky.JPG");
l6= new JLabel(icon);
l6.setBounds(0,0,1920,1000);
con.add(l6);


show();
setSize(1490,900);
}
public void actionPerformed(ActionEvent ee)
{
String n=j1.getText();
String p=jp.getText();
if(ee.getSource()==b1)
{
try
{
Statement st=cn.createStatement();
ResultSet rx=st.executeQuery("select * from admin");
while(rx.next())
{
String username=rx.getString(1);
String password=rx.getString(2);
if(username.compareTo(n)==0 && password.compareTo(p)==0)
{
new log();
}
else
{
JOptionPane.showMessageDialog(this,"Enter valid details");
}
}
}
catch(Exception e)
{
JOptionPane.showMessageDialog(this,"Database ERROR"+e);
}
}	
if(ee.getSource()==b3)
{
new user();	
}

}
public static void main(String sr[])
{
new admin();
}
}
